#include<stdio.h>
#include<stdlib.h>
int a[100][100];
int v[100];
int r[100][100];
int flag = 0;
void dfs(int i,int n,int src,int x,int y)
{
	v[i] = 1;
	if(v[x] == 1 && v[y] == 1)
		return;
	for(int j=1;j<=n;j++)
	{
		if(a[i][j]==1 && v[j]!=1)
		{
			printf("%d %d\n",i,j);	
			v[j] = 1;
			r[src][j] = 1;
			dfs(j,n,src,x,y);
		}
	}
}
int main()
{
	int n,x,y;
	scanf("%d %d %d",&n,&x,&y);
	for(int i=1;i<n;i++)
	{
		int u,v;
		scanf("%d %d",&u,&v);
		a[u][v] = 1;
		a[v][u] = 1;
	}
	int ct = 0;
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=n;j++)
		{
			v[j] = 0;
		}
		printf("\n");
		flag = 0;
		dfs(i,n,i,x,y);
	}
		for(int i=1;i<=n;i++)
		{
			for(int j=1;j<=n;j++)
			{
				printf("%d ",r[i][j]);
			}
			printf("\n");
		}
		for(int i=1;i<=n;i++)
		{
			for(int j=1;j<=n;j++)
			{
				if(r[i][j] == 1)
					ct++;				
			}
		}
		
	printf("%d\n",ct);
	return 0;
}